namespace FinalExam_200520350
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Standard obj=new Standard();

            obj.userID = 1;
            obj.firstName = "Suraj";
            obj.lastName = "Dhima";
            obj.address = "472 Grove";
            obj.phoneNumber = "78787878";
            obj.PostCode = "3332223344";
            obj.LibraryCardNbr = "123123";

            Resource r1 = new Resource();
            r1.Title = "Hard Work";
            r1.Code = "11";
            r1.Description = "A HardWorking book";
            r1.DatePublished = DateTime.Now;
            r1.Publisherinfo = "Suraj Corp.";

            Resource r2 = new Resource();
            r1.Title = "Love is in the air";
            r1.Code = "12";
            r1.Description = "A lovely meg";
            r1.DatePublished = DateTime.Now;
            r1.Publisherinfo = "Suraj Corp.";

            List<Resource> resources=new List<Resource>();
            resources.Add(r1);
            resources.Add(r2);

            Borrowing b1 = new Borrowing(obj.userID.ToString(), resources);
            b1.Start = DateTime.Now;
            b1.End = b1.Start.AddDays(10);


        }
    }
}