using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200520350
{
    internal class Borrowing: iDownloadable
    {
        public int RefereNumber;
        public string UserId;
        public DateTime Start;
        public DateTime End;
        public bool PickedUp=false;
        public List<Resource> Resources;
        private static int _lastReferenceNumber = 0;

        public Borrowing(string userId, List<Resource> resources)
        {
            UserId = userId;
            Resources = resources;
            RefereNumber = GenerateUniqueReferenceNumber();
        }
        
        private int GenerateUniqueReferenceNumber()
    {
        _lastReferenceNumber++;
        return _lastReferenceNumber;
    }

        public string GenerateAccessLink()
        {
            return "#1234567890";
        }

        public void ReturnResources(DateTime date)
        {
            if (date > this.End)
            {
                Console.WriteLine("You will be Fined!");
                this.PickedUp = true;
            }
            else
            {
                Console.WriteLine("Thank You!");
                this.PickedUp = true;
            }
        }
    }
}