using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200520350
{
    internal class Student:User
    {
        public int SchoolID;
        public string SchoolCardNbr;
        private DateTime BirthDate;

        public Student(int schoolID)
    {
        SchoolID = schoolID;
        SchoolCardNbr = string.Empty;
    }

    public DateTime DateOfBirth
    {
        get { return BirthDate; }
        set { BirthDate = value; }
    }

    }
}