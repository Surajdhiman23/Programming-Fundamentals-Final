using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200520350
{
    internal class Resource
    {
        public string Code;
        public string Title;
        public string Description;
        public string Publisherinfo;
        public DateTime DatePublished;

        public Resource()
    {
        Code = string.Empty;
        Title = string.Empty;
        Description = string.Empty;
        Publisherinfo = string.Empty;
        DatePublished = DateTime.MinValue;
    }

    }
}