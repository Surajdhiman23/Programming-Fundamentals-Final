using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam_200520350
{
    internal interface iDownloadable
    {
        public string GenerateAccessLink();
    }
}